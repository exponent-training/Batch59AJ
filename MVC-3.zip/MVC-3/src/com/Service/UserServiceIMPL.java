package com.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.DAO.DaoService;
import com.Entity.User;

@Service
public class UserServiceIMPL implements UserService {

	@Autowired
	private DaoService ds;
	
	@Override
	public void Register(User user) {
	System.out.println("I am in Service layer");
	System.out.println(user);
   ds.regiserInDao(user);	

	}
}
