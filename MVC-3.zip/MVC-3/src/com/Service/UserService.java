package com.Service;

import com.Entity.User;

public interface UserService {

	void Register(User user);

}
