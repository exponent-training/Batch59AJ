package com.DAO;

import com.Entity.User;

public interface DaoService {

	void regiserInDao(User user);

}
