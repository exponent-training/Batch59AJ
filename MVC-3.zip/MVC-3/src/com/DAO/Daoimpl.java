package com.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.Entity.User;

@Repository
public class Daoimpl implements DaoService {

	@Autowired
	private SessionFactory sf;

	@Override
	public void regiserInDao(User user) {

		System.out.println("I am in DAO layer");
		System.out.println(user);

		Session s = sf.openSession();
		s.save(user);
		s.beginTransaction().commit();
		System.out.println("User SAved");

	}
}
