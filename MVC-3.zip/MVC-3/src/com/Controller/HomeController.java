package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.Entity.LoginCred;
import com.Entity.User;
import com.Service.UserService;

@Controller
public class HomeController {

	// 100
	/*
	 * @RequestMapping(value = "/log") public String
	 * getLogRequest(@RequestParam("un") String username, @RequestParam("ps") String
	 * passowrd) { System.out.println(username + " " + passowrd);
	 * System.out.println("This is Backend Login Method"); return "Success"; }
	 */

	/*
	 * @RequestMapping(value = "/log") public String
	 * getLogRequestData(@ModelAttribute LoginCred loginDetails) {
	 * System.out.println(loginDetails);
	 * System.out.println("This is Backend Login Method"); return "Success"; }
	 */

	@Autowired
	private UserService us;

	@RequestMapping(value = "/reg")
	public String SignUp(@ModelAttribute User user) {
		System.out.println("I am in Controller layer");
		us.Register(user);
		
		return "login";

	}

}
